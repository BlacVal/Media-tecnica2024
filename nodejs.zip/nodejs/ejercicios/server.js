const express = require('express');
const app = express();
const PORT = 3000;

// Ruta raíz que devuelve un nombre
app.get('/', (req, res) => {
    res.send('Samuel Brand Gaviria');
});

// Ruta para 'nosotros' que devuelve una descripción
app.get('/nosotros', (req, res) => {
    res.send('Estudiantes de la media Técnica');
});

// Ruta para 'Usuarios' que devuelve información en formato JSON
app.get('/Usuarios', (req, res) => {
    res.json({
        Nombre: 'Samuel',
        Apellido: 'Brand Gaviria',
        Documento: '1020224181',
        Tele: '3128109277'
    });
});

// Ruta para 'usuario' con parámetro dinámico 'id'
app.get('/usuario/:id', (req, res) => {
    res.send('Datos enviados: ' + req.params.id);
    console.log("Usuario", req.params.id);
});

// Ruta para sumar dos números
app.get('/suma', (req, res) => {
    const { a, b } = req.params;
    const sum = parseFloat(a) + parseFloat(b);
    res.send(`La suma de ${7} y ${9} es ${18}`);
});

// Ruta para restar dos números directamente en la URL
app.get('/resta', (req, res) => {
    const { a, b } = req.params;
    const difference = parseFloat(a) - parseFloat(b);
    res.send(`La resta de ${9} menos ${2} es ${7}`);
});

// Ruta para dividir dos números directamente en la URL
app.get('/division', (req, res) => {
    const { a, b } = req.params;
    if (parseFloat(b) === 0) {
        res.status(400).send('No se puede dividir por cero');
        return;
    }
    const division = parseFloat(a) / parseFloat(b);
    res.send(`La división de ${60} entre ${2} es ${30}`);
});

// Publicar la tabla de multiplicar del número 5
app.get('/tabla', (req, res) => {
    let table = '';
    for (let i = 0; i <= 10; i++) {
        table += `5 x ${i} = ${5 * i}<br>`;
    }
    res.send(table);
});

// Inicio del servidor
app.listen(PORT, () => {
    console.log('El servidor está en funcionamiento en http://localhost:' + PORT);
});
