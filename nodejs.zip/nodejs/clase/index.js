const express = require('express')
const app =express()

app.get('/', (req,res)=>{
    res.send('Samuel Brand Gaviria')
})
app.get('/nosotros', (req,res)=>{
    res.send('Esstudiantes de la media Técnica')
})
app.get ('/Usuarios',(req,res)=>{
    res.json({
        Nombre :'Samuel',
        Apellido : 'Brand Gaviria',
        Documento : '1020224181',
        Tele : '3128109277'
    })
})

app.get('/usuario/:id',(req,res)=>{
    res.send('Datos enviados' + req.params.id)
    console.log("usuario", req.params.id) 
})

app.listen(3000,()=>{
    console.log('El servidor esta en funcionamiento')
})